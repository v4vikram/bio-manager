(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_swiper_5983b6f0._.js",
  "static/chunks/src_components_8f014ba2._.js"
],
    source: "dynamic"
});
